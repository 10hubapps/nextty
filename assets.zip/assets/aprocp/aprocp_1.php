<div id="step-container" class="step-container">
	<div id="s-ex" class="step-exit"><span class="material-icons-two-tone">cancel</span></div>
	<div class="step-app-content">
		<div class="step-icon-wrapper">
			<img src="" class="img-fluid app-step-icon" />
		</div>
		<div class="step-info-wrapper"></div>
		<div class="step-secondary-info-wrapper"></div>
	</div>
	<div class="step-proccesing-content">
		<div id="s-p-c-title">Download ready</div>
		<div id="s-p-c-msg">Click the button below in order to start with your app download.</div>
		<div class="s-p-c-btn-wrapper">
			<div id="sp-sb" class="s-p-c-btn animated pulse infinite"><span>Download Now</span></div>
		</div>
	</div>
	<div class="step-loader">
		<div class="ball-scale-multiple"><div></div><div></div><div></div></div>
	</div>
</div>