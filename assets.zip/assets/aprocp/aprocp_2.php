<div class="proccessing-wrapper">
	<div class="proccessing-content">
		<div class="proccessing-loader"><span class="material-icons-two-tone fa-spin">settings</span></div>
		<h3 class="proccessing-title animated pulse infinite"></h3>
		<div class="proccessing-msg"></div>
		<div id="progressBarConsole" class="proccessing-loadbar"><div></div></div>	
	</div>
</div>
<script type="text/javascript">
	var 
	$console_msg_string_1 = "Sit tight...";
	$console_msg_string_2 = "Downloading [appname].gz";
	$console_msg_string_3 = "Unpacking [appname].gz";
	$console_msg_string_4 = "Starting injection...";
	$console_msg_string_5 = "Setting up final stage...";
	$console_title_string_1 = "Proccessing...";
	$console_title_string_2 = "Waiting...";
</script>